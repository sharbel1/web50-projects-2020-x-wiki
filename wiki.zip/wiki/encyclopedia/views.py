from django.shortcuts import render, redirect
from . import util
import markdown2
import random
from django.http import Http404

def index(request):
    entries = util.list_entries()
    return render(request, "encyclopedia/index.html", {"entries": entries})

def entry(request, title):
    content = util.get_entry(title)
    if content is None:
        raise Http404("Entry not found")
    html_content = markdown2.markdown(content)
    return render(request, "encyclopedia/entry.html", {"entryTitle": title, "entry": html_content})

def search(request):
    query = request.GET.get('q')
    if query:
        entries = util.list_entries()
        matching_entries = [entry for entry in entries if query.lower() in entry.lower()]
        return render(request, "encyclopedia/index.html", {"entries": matching_entries, "search": True, "value": query})
    else:
        return redirect('index')

def create(request):
    if request.method == "POST":
        title = request.POST.get("title")
        content = request.POST.get("content")
        if title and content:
            if util.get_entry(title):
                return render(request, "encyclopedia/error.html", {"error_message": "Entry already exists."})
            else:
                util.save_entry(title, content)
                return redirect('entry', title=title)
    return render(request, "encyclopedia/create.html")


def edit(request, title):
    if request.method == "POST":
        content = request.POST.get("content")
        util.save_entry(title, content)
        return redirect('entry', title=title)
    else:
        content = util.get_entry(title)
        return render(request, "encyclopedia/edit.html", {"entryTitle": title, "entry": content})


def random_page(request):
    entries = util.list_entries()
    title = random.choice(entries)
    return redirect('entry', title=title)

